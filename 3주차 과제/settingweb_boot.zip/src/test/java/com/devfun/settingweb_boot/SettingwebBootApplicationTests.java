package com.devfun.settingweb_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SettingwebBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
