package com.devfun.settingweb_boot.dto;

public class StatisticDto {

}
